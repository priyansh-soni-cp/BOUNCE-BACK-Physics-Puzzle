extends Node2D

# Game loop orchestrator: loads current level and coordinates UI

@onready var level_container: Node2D = $LevelContainer
@onready var background: Node2D = $Background
@onready var ui_overlay: CanvasLayer = $UIOverlay

var current_level_node: Node = null

func _ready() -> void:
	load_level(GameManager.current_level_idx)

func load_level(idx: int) -> void:
	if current_level_node:
		current_level_node.queue_free()
		current_level_node = null

	# Prepare counts first so registered collectibles increment properly
	GameManager.prepare_level_start(idx)

	var path = GameManager.levels[idx]
	var packed = load(path) as PackedScene
	if packed:
		current_level_node = packed.instantiate()
		level_container.add_child(current_level_node)
		GameManager.notify_level_ready()
	else:
		push_error("Could not load level scene: " + path)
