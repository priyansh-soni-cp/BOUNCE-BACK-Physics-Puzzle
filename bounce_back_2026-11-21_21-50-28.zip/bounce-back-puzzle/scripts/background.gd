extends Node2D

# Minimalist dark arena background with subtle grid dots

func _ready() -> void:
	z_index = -100

func _draw() -> void:
	var vp = get_viewport_rect().size
	
	# Solid deep black background
	draw_rect(Rect2(Vector2.ZERO, vp), Color(0.04, 0.04, 0.05), true)
	
	# Subtle technical grid dots (every 48px)
	var dot_color = Color(0.12, 0.12, 0.16)
	var step = 48.0
	var x = step
	while x < vp.x:
		var y = step
		while y < vp.y:
			draw_circle(Vector2(x, y), 1.2, dot_color)
			y += step
		x += step
	
	# Inner boundary border line
	var border_rect = Rect2(8, 8, vp.x - 16, vp.y - 16)
	draw_rect(border_rect, Color(0.15, 0.15, 0.20), false, 1.0)
