extends Control

# Main menu controller with level selection and settings

@onready var main_buttons: VBoxContainer = $CenterContainer/MainVBox/MenuButtons
@onready var play_btn: Button = $CenterContainer/MainVBox/MenuButtons/PlayBtn
@onready var levels_btn: Button = $CenterContainer/MainVBox/MenuButtons/LevelsBtn
@onready var settings_btn: Button = $CenterContainer/MainVBox/MenuButtons/SettingsBtn
@onready var quit_btn: Button = $CenterContainer/MainVBox/MenuButtons/QuitBtn

# Level Select Modal
@onready var level_select_modal: Control = $LevelSelectModal
@onready var lvl_1_btn: Button = $LevelSelectModal/Center/Panel/VBox/LevelGrid/Lvl1Btn
@onready var lvl_2_btn: Button = $LevelSelectModal/Center/Panel/VBox/LevelGrid/Lvl2Btn
@onready var lvl_3_btn: Button = $LevelSelectModal/Center/Panel/VBox/LevelGrid/Lvl3Btn
@onready var lvl_4_btn: Button = $LevelSelectModal/Center/Panel/VBox/LevelGrid/Lvl4Btn
@onready var level_back_btn: Button = $LevelSelectModal/Center/Panel/VBox/BackBtn

# Settings Modal
@onready var settings_modal: Control = $SettingsModal
@onready var master_slider: HSlider = $SettingsModal/Center/Panel/VBox/MasterRow/MasterSlider
@onready var sfx_slider: HSlider = $SettingsModal/Center/Panel/VBox/SfxRow/SfxSlider
@onready var fullscreen_check: CheckBox = $SettingsModal/Center/Panel/VBox/FullscreenCheck
@onready var assist_check: CheckBox = $SettingsModal/Center/Panel/VBox/AssistCheck
@onready var settings_close_btn: Button = $SettingsModal/Center/Panel/VBox/CloseBtn

func _ready() -> void:
	level_select_modal.visible = false
	settings_modal.visible = false
	
	play_btn.pressed.connect(_on_play_pressed)
	levels_btn.pressed.connect(_on_levels_pressed)
	settings_btn.pressed.connect(_on_settings_pressed)
	quit_btn.pressed.connect(_on_quit_pressed)

	level_back_btn.pressed.connect(func():
		AudioManager.play("ui_click")
		level_select_modal.visible = false
	)
	
	settings_close_btn.pressed.connect(func():
		AudioManager.play("ui_click")
		settings_modal.visible = false
	)

	lvl_1_btn.pressed.connect(func(): _start_specific_level(0))
	lvl_2_btn.pressed.connect(func(): _start_specific_level(1))
	lvl_3_btn.pressed.connect(func(): _start_specific_level(2))
	lvl_4_btn.pressed.connect(func(): _start_specific_level(3))

	_setup_settings_controls()

func _setup_settings_controls() -> void:
	master_slider.value = AudioManager.master_volume * 100.0
	sfx_slider.value = AudioManager.sfx_volume * 100.0
	assist_check.button_pressed = GameManager.show_trajectory_assist
	
	var is_fs = DisplayServer.window_get_mode() == DisplayServer.WINDOW_MODE_FULLSCREEN
	fullscreen_check.button_pressed = is_fs

	master_slider.value_changed.connect(func(val):
		AudioManager.master_volume = val / 100.0
	)
	
	sfx_slider.value_changed.connect(func(val):
		AudioManager.sfx_volume = val / 100.0
	)
	
	assist_check.toggled.connect(func(toggled):
		GameManager.show_trajectory_assist = toggled
	)
	
	fullscreen_check.toggled.connect(func(toggled):
		if toggled:
			DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
		else:
			DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
	)

func _on_play_pressed() -> void:
	AudioManager.play("ui_click")
	GameManager.go_to_level(GameManager.unlocked_level)

func _on_levels_pressed() -> void:
	AudioManager.play("ui_click")
	_refresh_level_buttons()
	level_select_modal.visible = true

func _refresh_level_buttons() -> void:
	var btns = [lvl_1_btn, lvl_2_btn, lvl_3_btn, lvl_4_btn]
	var titles = ["STAGE 1 // REBOUND 101", "STAGE 2 // SPRING VAULT", "STAGE 3 // SPEED KILLER", "STAGE 4 // APEX ARENA"]
	
	for i in range(btns.size()):
		var b = btns[i]
		var unlocked = (i <= GameManager.unlocked_level)
		b.disabled = not unlocked
		
		var stars = ""
		for s in range(3):
			stars += "★" if s < GameManager.level_stars[i] else "☆"
		
		if unlocked:
			b.text = titles[i] + "  [" + stars + "]"
		else:
			b.text = titles[i] + "  [LOCKED]"

func _start_specific_level(idx: int) -> void:
	AudioManager.play("ui_click")
	GameManager.go_to_level(idx)

func _on_settings_pressed() -> void:
	AudioManager.play("ui_click")
	settings_modal.visible = true

func _on_quit_pressed() -> void:
	get_tree().quit()
