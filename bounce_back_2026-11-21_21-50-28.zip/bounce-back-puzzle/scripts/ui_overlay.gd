extends CanvasLayer

# In-game HUD, pause menu, and level clear overlay

@onready var level_label: Label = $TopBar/HBox/StageBadge/LevelLabel
@onready var star_label: Label = $TopBar/HBox/StarLabel
@onready var bounce_label: Label = $TopBar/HBox/BounceLabel
@onready var restart_btn: Button = $TopBar/HBox/RestartBtn
@onready var menu_btn: Button = $TopBar/HBox/MenuBtn

# Pause modal
@onready var pause_modal: ColorRect = $PauseModal
@onready var resume_btn: Button = $PauseModal/Center/Panel/VBox/ResumeBtn
@onready var pause_restart_btn: Button = $PauseModal/Center/Panel/VBox/RestartBtn
@onready var pause_menu_btn: Button = $PauseModal/Center/Panel/VBox/MenuBtn

# Victory modal
@onready var win_modal: ColorRect = $WinModal
@onready var win_title: Label = $WinModal/Center/Panel/VBox/Title
@onready var win_stars: Label = $WinModal/Center/Panel/VBox/Stars
@onready var win_stats: Label = $WinModal/Center/Panel/VBox/Stats
@onready var next_btn: Button = $WinModal/Center/Panel/VBox/HBox/NextBtn
@onready var replay_btn: Button = $WinModal/Center/Panel/VBox/HBox/ReplayBtn

func _ready() -> void:
	pause_modal.visible = false
	win_modal.visible = false

	GameManager.level_loaded.connect(_on_level_loaded)
	GameManager.stars_updated.connect(_on_stars_updated)
	GameManager.bounces_updated.connect(_on_bounces_updated)
	GameManager.level_won.connect(_on_level_won)

	restart_btn.pressed.connect(_on_restart_pressed)
	menu_btn.pressed.connect(_toggle_pause)
	
	resume_btn.pressed.connect(_toggle_pause)
	pause_restart_btn.pressed.connect(_on_restart_pressed)
	pause_menu_btn.pressed.connect(_on_menu_pressed)
	
	next_btn.pressed.connect(func(): GameManager.load_next_level())
	replay_btn.pressed.connect(_on_restart_pressed)

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel") or (event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE):
		if not win_modal.visible:
			_toggle_pause()
	elif event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_R:
			_on_restart_pressed()
		elif (event.keycode == KEY_ENTER or event.keycode == KEY_SPACE) and win_modal.visible:
			GameManager.load_next_level()

func _toggle_pause() -> void:
	AudioManager.play("ui_click")
	pause_modal.visible = not pause_modal.visible

func _on_level_loaded(idx: int) -> void:
	level_label.text = "STAGE " + str(idx)

func _on_stars_updated(current: int, total: int) -> void:
	star_label.text = "GEMS: " + str(current) + " / " + str(total)

func _on_bounces_updated(count: int) -> void:
	bounce_label.text = "BOUNCES: " + str(count)

func _on_level_won(lvl_idx: int, stars: int, total_stars: int, bounces: int) -> void:
	win_modal.visible = true
	win_title.text = ">> STAGE " + str(lvl_idx) + " CLEAR! <<"
	
	var star_str = ""
	for i in range(max(1, total_stars)):
		star_str += "★ " if i < stars else "☆ "
	win_stars.text = star_str.strip_edges()
	
	win_stats.text = "Gems: " + str(stars) + "/" + str(total_stars) + "   •   Bounces: " + str(bounces)

func _on_restart_pressed() -> void:
	GameManager.restart_current_level()

func _on_menu_pressed() -> void:
	GameManager.go_to_menu()
