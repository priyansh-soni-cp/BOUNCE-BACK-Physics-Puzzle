extends CharacterBody2D

# Player projectile controller (Slime Hopper)
# Uses authentic 2D sprite texture with physics squash & stretch and trajectory guide

signal target_reached

enum State { READY, AIMING, MOVING, WON }

@export var gravity: float = 480.0
@export var max_pull: float = 160.0
@export var launch_multiplier: float = 5.2
@export var base_rebound: float = 0.84
@export var min_stop_speed: float = 25.0

var state: State = State.READY
var spawn_pos: Vector2
var drag_anchor: Vector2 = Vector2.ZERO
var drag_pos: Vector2 = Vector2.ZERO
var idle_time: float = 0.0

var sprite: Sprite2D
var guide_line: Line2D
var aim_arrow: Node2D
const BASE_SPRITE_SCALE: Vector2 = Vector2(0.56, 0.56)

func _ready() -> void:
	add_to_group("player")
	spawn_pos = global_position
	_setup_sprite()
	_setup_guide()

func _setup_sprite() -> void:
	sprite = Sprite2D.new()
	sprite.name = "CharacterSprite"
	var tex = load("res://assets/sprites/player.png") as Texture2D
	if tex:
		sprite.texture = tex
	sprite.scale = BASE_SPRITE_SCALE
	add_child(sprite)

func _setup_guide() -> void:
	guide_line = Line2D.new()
	guide_line.width = 3.0
	guide_line.default_color = Color(0.0, 0.9, 1.0, 0.8)
	guide_line.top_level = true
	guide_line.begin_cap_mode = Line2D.LINE_CAP_ROUND
	guide_line.end_cap_mode = Line2D.LINE_CAP_ROUND
	guide_line.visible = false
	add_child(guide_line)

	aim_arrow = Node2D.new()
	aim_arrow.draw.connect(_draw_aim_arrow)
	add_child(aim_arrow)

func _physics_process(delta: float) -> void:
	match state:
		State.AIMING:
			_process_aim()
		State.MOVING:
			_process_movement(delta)
		State.READY:
			velocity = Vector2.ZERO

	aim_arrow.queue_redraw()

func _unhandled_input(event: InputEvent) -> void:
	if state == State.WON:
		return

	if event is InputEventMouseButton:
		var mb = event as InputEventMouseButton
		if mb.button_index == MOUSE_BUTTON_LEFT:
			if mb.pressed:
				if state == State.READY:
					_begin_aim(mb.position)
			elif state == State.AIMING:
				_release_launch()

	elif event is InputEventMouseMotion and state == State.AIMING:
		drag_pos = event.position

func _begin_aim(click_pos: Vector2) -> void:
	state = State.AIMING
	drag_anchor = global_position
	drag_pos = click_pos
	guide_line.visible = GameManager.show_trajectory_assist

func _process_aim() -> void:
	var pull = drag_anchor - drag_pos
	if pull.length() > max_pull:
		pull = pull.normalized() * max_pull

	if GameManager.show_trajectory_assist:
		_render_trajectory(global_position, pull * launch_multiplier)
	else:
		guide_line.clear_points()

func _release_launch() -> void:
	var pull = drag_anchor - drag_pos
	if pull.length() > max_pull:
		pull = pull.normalized() * max_pull

	guide_line.visible = false

	if pull.length() < 12.0:
		state = State.READY
		return

	state = State.MOVING
	velocity = pull * launch_multiplier
	idle_time = 0.0

	GameManager.add_shot()
	AudioManager.play("launch")
	_squash(Vector2(0.42, 0.72))

func _process_movement(delta: float) -> void:
	velocity.y += gravity * delta

	# Slight tilt in direction of velocity
	if abs(velocity.x) > 20:
		sprite.rotation = lerp_angle(sprite.rotation, clamp(velocity.x * 0.0015, -0.6, 0.6), 0.15)

	var collision = move_and_collide(velocity * delta)
	if collision:
		_on_collide(collision)

	if velocity.length() < min_stop_speed:
		idle_time += delta
		if idle_time > 0.9:
			reset_to_start()
	else:
		idle_time = 0.0

func _on_collide(collision: KinematicCollision2D) -> void:
	var collider = collision.get_collider()
	var normal = collision.get_normal()
	var rebound = base_rebound

	if collider and collider.is_in_group("bumper"):
		rebound = 1.35
		AudioManager.play("bounce_bumper")
		if collider.has_method("trigger_bounce"):
			collider.trigger_bounce()
	elif collider and collider.is_in_group("dampener"):
		rebound = 0.28
		AudioManager.play("bounce_dampener")
	else:
		AudioManager.play("bounce_wall")

	GameManager.add_bounce()
	velocity = velocity.bounce(normal) * rebound

	var dir = normal.abs()
	_squash(Vector2(
		BASE_SPRITE_SCALE.x * lerp(1.35, 0.7, dir.x),
		BASE_SPRITE_SCALE.y * lerp(1.35, 0.7, dir.y)
	))

func _squash(target: Vector2) -> void:
	var tw = create_tween().set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	tw.tween_property(sprite, "scale", target, 0.06)
	tw.tween_property(sprite, "scale", BASE_SPRITE_SCALE, 0.18)

func _render_trajectory(start_pos: Vector2, initial_vel: Vector2) -> void:
	guide_line.clear_points()
	var points: Array[Vector2] = []
	var p = start_pos
	var v = initial_vel
	var dt = 0.03
	var space = get_world_2d().direct_space_state

	points.append(p)
	var max_bounces = 2

	for i in range(50):
		var next_p = p + v * dt
		v.y += gravity * dt

		var ray = PhysicsRayQueryParameters2D.create(p, next_p)
		ray.exclude = [get_rid()]
		var res = space.intersect_ray(ray)

		if res:
			points.append(res.position)
			if max_bounces > 0:
				max_bounces -= 1
				var factor = base_rebound
				if res.collider and res.collider.is_in_group("bumper"):
					factor = 1.35
				elif res.collider and res.collider.is_in_group("dampener"):
					factor = 0.28
				v = v.bounce(res.normal) * factor
				p = res.position + res.normal * 1.5
			else:
				break
		else:
			p = next_p
			points.append(p)

	for pt in points:
		guide_line.add_point(pt)

func reach_target() -> void:
	state = State.WON
	velocity = Vector2.ZERO
	guide_line.visible = false

	var tw = create_tween().set_parallel(true).set_trans(Tween.TRANS_QUAD)
	tw.tween_property(sprite, "scale", BASE_SPRITE_SCALE * 1.4, 0.2)
	tw.tween_property(sprite, "scale", Vector2.ZERO, 0.25).set_delay(0.2)

	target_reached.emit()
	GameManager.complete_level()

func reset_to_start() -> void:
	state = State.READY
	velocity = Vector2.ZERO
	global_position = spawn_pos
	sprite.rotation = 0.0
	sprite.scale = BASE_SPRITE_SCALE
	AudioManager.play("bounce_wall")

func _draw_aim_arrow() -> void:
	if state == State.AIMING:
		var pull = drag_anchor - drag_pos
		if pull.length() > max_pull:
			pull = pull.normalized() * max_pull
		
		# Draw pull trajectory arrow behind character
		aim_arrow.draw_line(Vector2.ZERO, -pull * 0.45, Color(1.0, 0.2, 0.35, 0.8), 3.0)
		aim_arrow.draw_circle(-pull * 0.45, 4.0, Color(1.0, 0.4, 0.5))
