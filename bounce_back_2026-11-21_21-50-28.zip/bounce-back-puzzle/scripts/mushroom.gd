extends StaticBody2D

# Mechanical pinball bumper with authentic 2D sprite texture

@export var pad_width: float = 72.0
@export var pad_height: float = 30.0

var sprite: Sprite2D
const BASE_SCALE: Vector2 = Vector2(0.75, 0.75)

func _ready() -> void:
	add_to_group("bumper")
	_setup_sprite()

func _setup_sprite() -> void:
	sprite = Sprite2D.new()
	sprite.name = "BumperSprite"
	var tex = load("res://assets/sprites/bumper.png") as Texture2D
	if tex:
		sprite.texture = tex
	sprite.position = Vector2(0, -6)
	sprite.scale = BASE_SCALE
	add_child(sprite)

func trigger_bounce() -> void:
	var tw = create_tween().set_trans(Tween.TRANS_ELASTIC).set_ease(Tween.EASE_OUT)
	sprite.scale = Vector2(BASE_SCALE.x * 1.3, BASE_SCALE.y * 0.6)
	tw.tween_property(sprite, "scale", BASE_SCALE, 0.35)
