extends Area2D

# Goal target warp portal using authentic 2D sprite texture

var sprite: Sprite2D
var phase: float = 0.0
var captured: bool = false
const BASE_SCALE: Vector2 = Vector2(0.85, 0.85)

func _ready() -> void:
	_setup_sprite()
	body_entered.connect(_on_body_entered)

func _setup_sprite() -> void:
	sprite = Sprite2D.new()
	sprite.name = "PortalSprite"
	var tex = load("res://assets/sprites/target.png") as Texture2D
	if tex:
		sprite.texture = tex
	sprite.scale = BASE_SCALE
	add_child(sprite)

func _process(delta: float) -> void:
	phase += delta * 2.5
	# Slow hypnotic portal spin
	sprite.rotation += delta * 1.2
	var pulse = 0.92 + 0.08 * sin(phase)
	sprite.scale = BASE_SCALE * pulse

func _on_body_entered(body: Node2D) -> void:
	if captured:
		return
	if body.is_in_group("player") or body.name == "Pebble":
		captured = true
		
		var tw = create_tween().set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
		tw.tween_property(body, "global_position", global_position, 0.22)
		
		if body.has_method("reach_target"):
			body.reach_target()
