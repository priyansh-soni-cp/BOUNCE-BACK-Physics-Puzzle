@tool
extends StaticBody2D

# Modular collision obstacle (girder wall / dampener / bumper)

enum Type { STANDARD, DAMPENER, BUMPER }

@export var surface_type: Type = Type.STANDARD:
	set(val):
		surface_type = val
		_refresh_type()
		if visual_node:
			visual_node.queue_redraw()

@export var size: Vector2 = Vector2(160, 24):
	set(val):
		size = val
		_refresh_collision()
		if visual_node:
			visual_node.queue_redraw()

var visual_node: Node2D
var tex_metal: Texture2D
var tex_damp: Texture2D

func _ready() -> void:
	tex_metal = load("res://assets/sprites/platform_metal.png") as Texture2D
	tex_damp = load("res://assets/sprites/platform_dampener.png") as Texture2D
	_refresh_type()
	_refresh_collision()
	_setup_visual()

func _refresh_type() -> void:
	remove_from_group("bumper")
	remove_from_group("dampener")
	
	match surface_type:
		Type.DAMPENER:
			add_to_group("dampener")
		Type.BUMPER:
			add_to_group("bumper")
		Type.STANDARD:
			pass

func _refresh_collision() -> void:
	if not has_node("CollisionShape2D"):
		return
	var col = $CollisionShape2D
	var rect = RectangleShape2D.new()
	rect.size = size
	col.shape = rect

func _setup_visual() -> void:
	if not visual_node:
		visual_node = Node2D.new()
		visual_node.name = "Render"
		add_child(visual_node)
		visual_node.draw.connect(_draw_platform)
	visual_node.queue_redraw()

func _draw_platform() -> void:
	var rect = Rect2(-size.x * 0.5, -size.y * 0.5, size.x, size.y)
	
	var tex = tex_metal if surface_type != Type.DAMPENER else tex_damp
	if tex:
		# Tile the sprite texture cleanly across the platform size
		draw_texture_rect(tex, rect, true)
	else:
		var col = Color(0.18, 0.20, 0.26) if surface_type != Type.DAMPENER else Color(0.06, 0.20, 0.12)
		draw_rect(rect, col, true)

	# Clean bevel highlight
	var border_col = Color(0.35, 0.40, 0.50) if surface_type != Type.DAMPENER else Color(0.0, 0.85, 0.5)
	draw_rect(rect, border_col, false, 1.5)
