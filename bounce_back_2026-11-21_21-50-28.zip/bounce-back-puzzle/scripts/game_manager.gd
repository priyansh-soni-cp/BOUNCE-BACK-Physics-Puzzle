extends Node

# Core game state & progression manager

signal level_loaded(level_idx: int)
signal stars_updated(current: int, total: int)
signal bounces_updated(count: int)
signal level_won(level_idx: int, stars: int, total_stars: int, bounces: int)
signal assist_mode_toggled(enabled: bool)

var levels: Array[String] = [
	"res://scenes/levels/level_1.tscn",
	"res://scenes/levels/level_2.tscn",
	"res://scenes/levels/level_3.tscn",
	"res://scenes/levels/level_4.tscn"
]

var current_level_idx: int = 0
var stars_collected: int = 0
var total_stars_in_level: int = 0
var bounce_count: int = 0
var shot_count: int = 0
var level_active: bool = false

# Player settings
var show_trajectory_assist: bool = true
var high_contrast: bool = true

# Progress tracking (stars earned per level: 0 to 3)
var level_stars: Array[int] = [0, 0, 0, 0]
var unlocked_level: int = 0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS

func prepare_level_start(idx: int) -> void:
	current_level_idx = clampi(idx, 0, levels.size() - 1)
	stars_collected = 0
	total_stars_in_level = 0
	bounce_count = 0
	shot_count = 0
	level_active = true
	AudioManager.reset_scale()

func notify_level_ready() -> void:
	level_loaded.emit(current_level_idx + 1)
	stars_updated.emit(stars_collected, total_stars_in_level)
	bounces_updated.emit(bounce_count)

func register_star() -> void:
	total_stars_in_level += 1
	stars_updated.emit(stars_collected, total_stars_in_level)

func collect_star() -> void:
	stars_collected += 1
	AudioManager.play_collect_star()
	stars_updated.emit(stars_collected, total_stars_in_level)

func add_bounce() -> void:
	bounce_count += 1
	bounces_updated.emit(bounce_count)

func add_shot() -> void:
	shot_count += 1

func complete_level() -> void:
	if not level_active:
		return
	level_active = false
	AudioManager.play("target_hit")
	AudioManager.play_clear_fanfare()
	
	if stars_collected > level_stars[current_level_idx]:
		level_stars[current_level_idx] = stars_collected
	
	if current_level_idx + 1 > unlocked_level and current_level_idx + 1 < levels.size():
		unlocked_level = current_level_idx + 1

	level_won.emit(current_level_idx + 1, stars_collected, total_stars_in_level, bounce_count)

func restart_current_level() -> void:
	AudioManager.play("ui_click")
	get_tree().change_scene_to_file("res://scenes/main.tscn")

func load_next_level() -> void:
	AudioManager.play("ui_click")
	if current_level_idx + 1 < levels.size():
		current_level_idx += 1
		get_tree().change_scene_to_file("res://scenes/main.tscn")
	else:
		# Return to main menu if completed all
		get_tree().change_scene_to_file("res://scenes/main_menu.tscn")

func go_to_level(idx: int) -> void:
	current_level_idx = clampi(idx, 0, levels.size() - 1)
	get_tree().change_scene_to_file("res://scenes/main.tscn")

func go_to_menu() -> void:
	AudioManager.play("ui_click")
	get_tree().change_scene_to_file("res://scenes/main_menu.tscn")
