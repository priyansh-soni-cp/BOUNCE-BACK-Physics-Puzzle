extends Node

# Procedural SFX synthesizer
# Generates audio tones dynamically via AudioStreamWAV

var sound_cache: Dictionary = {}
var audio_players: Array[AudioStreamPlayer] = []
const MAX_PLAYERS: int = 8
var current_player_idx: int = 0

var master_volume: float = 1.0
var sfx_volume: float = 1.0

# Pentatonic scale notes (Hz)
const NOTES: Array[float] = [
	261.63, # C4
	293.66, # D4
	329.63, # E4
	392.00, # G4
	440.00, # A4
	523.25, # C5
	587.33, # D5
	659.25  # E5
]

var note_idx: int = 0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for i in range(MAX_PLAYERS):
		var p = AudioStreamPlayer.new()
		add_child(p)
		audio_players.append(p)
	
	_bake_sounds()

func _bake_sounds() -> void:
	sound_cache["launch"] = _create_sample(360.0, 0.16, 14.0, 0.45, true)
	sound_cache["bounce_wall"] = _create_sample(220.0, 0.12, 22.0, 0.35)
	sound_cache["bounce_bumper"] = _create_sample(520.0, 0.32, 6.0, 0.6)
	sound_cache["bounce_dampener"] = _create_sample(110.0, 0.18, 16.0, 0.35)
	sound_cache["target_hit"] = _create_sample(440.0, 0.5, 4.0, 0.55)
	sound_cache["ui_click"] = _create_sample(480.0, 0.08, 30.0, 0.3)

func _create_sample(freq: float, duration: float, decay: float, amp: float = 0.5, pitch_drop: bool = false) -> AudioStreamWAV:
	var stream = AudioStreamWAV.new()
	stream.format = AudioStreamWAV.FORMAT_16_BITS
	stream.mix_rate = 22050
	stream.stereo = false
	
	var total_samples = int(stream.mix_rate * duration)
	var bytes = PackedByteArray()
	bytes.resize(total_samples * 2)
	
	for i in range(total_samples):
		var t = float(i) / float(stream.mix_rate)
		var f = freq
		if pitch_drop:
			f = freq * (1.0 + 0.4 * (1.0 - (t / duration)))
		
		var attack = min(1.0, t / 0.006)
		var envelope = attack * exp(-decay * t)
		
		# Clean tone with slight harmonics
		var wave = sin(TAU * f * t) * 0.8 + sin(TAU * f * 2.0 * t) * 0.2
		var val = clamp(wave * envelope * amp, -1.0, 1.0)
		var s16 = int(val * 32767.0)
		bytes.encode_s16(i * 2, s16)
		
	stream.data = bytes
	return stream

func play(sname: String) -> void:
	if sound_cache.has(sname):
		_play_stream(sound_cache[sname])

func play_collect_star() -> void:
	var freq = NOTES[clampi(note_idx, 0, NOTES.size() - 1)]
	note_idx = (note_idx + 1) % NOTES.size()
	_play_stream(_create_sample(freq, 0.35, 5.0, 0.55))

func reset_scale() -> void:
	note_idx = 0

func play_clear_fanfare() -> void:
	var chord = [NOTES[2], NOTES[4], NOTES[5]]
	for i in range(chord.size()):
		get_tree().create_timer(i * 0.12).timeout.connect(func():
			_play_stream(_create_sample(chord[i], 0.6, 3.5, 0.5))
		)

func _play_stream(stream: AudioStream) -> void:
	if audio_players.is_empty():
		return
	var player = audio_players[current_player_idx]
	current_player_idx = (current_player_idx + 1) % MAX_PLAYERS
	player.stream = stream
	player.volume_db = linear_to_db(master_volume * sfx_volume)
	player.play()
