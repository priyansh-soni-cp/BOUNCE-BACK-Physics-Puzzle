extends Area2D

# Collectible star gem using authentic 2D sprite texture

var start_y: float = 0.0
var sprite: Sprite2D
var phase: float = 0.0
var collected: bool = false
const BASE_SCALE: Vector2 = Vector2(0.7, 0.7)

func _ready() -> void:
	start_y = position.y
	phase = randf_range(0.0, TAU)
	_setup_sprite()
	body_entered.connect(_on_body_entered)
	GameManager.register_star()

func _setup_sprite() -> void:
	sprite = Sprite2D.new()
	sprite.name = "StarSprite"
	var tex = load("res://assets/sprites/star.png") as Texture2D
	if tex:
		sprite.texture = tex
	sprite.scale = BASE_SCALE
	add_child(sprite)

func _process(delta: float) -> void:
	if collected:
		return
	phase += delta * 3.2
	position.y = start_y + sin(phase) * 5.0
	sprite.rotation = sin(phase * 0.5) * 0.12
	var pulse = 0.95 + 0.05 * sin(phase * 1.5)
	sprite.scale = BASE_SCALE * pulse

func _on_body_entered(body: Node2D) -> void:
	if collected or not body.is_in_group("player"):
		return
	
	collected = true
	GameManager.collect_star()
	
	var tw = create_tween().set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_IN)
	tw.tween_property(sprite, "scale", BASE_SCALE * 1.6, 0.1)
	tw.tween_property(sprite, "scale", Vector2.ZERO, 0.15)
	tw.tween_callback(queue_free)
