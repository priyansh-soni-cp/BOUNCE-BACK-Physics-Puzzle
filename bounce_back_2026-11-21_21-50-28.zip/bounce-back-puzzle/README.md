# BOUNCE BACK

A minimalist 2D physics puzzle game built in Godot 4.

## Core Mechanic
Direct paths to the target are obstructed. Players must slingshot the projectile to ricochet off obstacles, angled deflectors, and spring bumpers to rebound backwards into the goal zone.

---

## Levels
* **01 // INTRODUCTION**: Fundamentals of the rebound mechanic. Wide ricochet corridor with generous target entry.
* **02 // BUMPERS**: Introduces spring bumpers that amplify projectile velocity and bounce height.
* **03 // DAMPENER**: Introduces dampener pads that absorb excessive speed to drop into protected vertical chutes.
* **04 // APEX**: The final challenge combining multi-bumper ricochets, ceiling deflection, and precision landing.

---

## Controls
* **Mouse Click & Drag**: Aim launch vector and preview rebound trajectory.
* **Release**: Launch projectile.
* **R**: Instant retry.
* **ESC**: Pause menu & options.
* **Enter / Space**: Advance to next level from victory overlay.

---

## Features
* **Custom Trajectory Guide**: Real-time raycasted physics simulation displaying predicted bounce vectors.
* **Procedural Sound Engine**: Dynamic 16-bit audio synthesis for ricochets, bumpers, and harmonic collectible tones without external audio file dependencies.
* **Settings & Progression**: Master and SFX audio sliders, fullscreen toggle, trajectory assist toggle, and star tracking across all levels.
